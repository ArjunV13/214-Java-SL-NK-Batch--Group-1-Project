import { MarkAsteriskDirective } from './mark-asterisk.directive';

describe('MarkAsteriskDirective', () => {
  it('should create an instance', () => {
    const directive = new MarkAsteriskDirective();
    expect(directive).toBeTruthy();
  });
});
