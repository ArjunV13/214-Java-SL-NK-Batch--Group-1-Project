export interface cart{
    medicineimage:ImageBitmap;
    medicineId:number;
    medicineName:string;
    description:string;
    price:number;
}